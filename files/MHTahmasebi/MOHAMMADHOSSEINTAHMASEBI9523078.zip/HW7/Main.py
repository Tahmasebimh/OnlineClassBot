import cv2 as cv
import numpy as np
import matplotlib.pyplot as mtplot
import glob
from numpy import linalg as la


def loadImage(address):
    img = cv.imread(address, 0)
    img = cv.resize(img, (30, 30))
    return np.array([np.array(img).flatten()]).transpose(), np.array(img.copy())


def loadFacesUtils(address):
    imageList = []
    i = 0
    if len(glob.glob(address + "\\*")) > 0:
        if len(glob.glob((address + "\\*.pgm"))) > 0:
            for f in glob.glob((address + "\\*.pgm")):
                flate, _ = np.array(loadImage(f))
                flate = flate / np.max(flate)
                if len(imageList) > 0:
                    imageList = np.append(imageList, flate, axis=1)
                else:
                    imageList = np.array(flate.copy())
        else:
            for f in glob.glob((address + "\\*")):
                list = np.array(loadFacesUtils(f))
                if len(imageList) > 0:
                    imageList = np.append(imageList, list, axis=1)
                else:
                    imageList = np.array(list.copy())
    return np.array(imageList)


def loadFaces(address):
    faces = loadFacesUtils(address)
    return faces


def findEigenFaces(cov, num=25):
    eighenValue, eigenVector = la.eig(cov)
    sortedValueArgs = [i[0] for i in sorted(enumerate(eighenValue), key=lambda x: abs(x[1]))]
    sortedValueArgs = np.array([sortedValueArgs])
    sortedValue = sorted(eighenValue, key=lambda x: abs(x))
    finalValues = np.zeros((1, num), dtype="complex_")
    sortedValue = np.array([sortedValue], dtype="complex_")
    for i in range(num):
        finalValues[0, i] = sortedValue[0, (len(sortedValue[0]) - 1 - i)]
    vectorHelper = np.zeros((len(np.array(eigenVector)), num), dtype="complex_")
    eigenVector = np.array(eigenVector)
    for i in range(len(eigenVector)):
        for j in range(num):
            vectorHelper[i, j] = eigenVector[i, sortedValueArgs[0, (len(sortedValueArgs[0])) - 1 - j]]
    return vectorHelper, finalValues


def showEigenFaces(efaces, size=[3, 3]):
    img = np.array(efaces[:, 0:(size[0] * size[1])], dtype="float")
    for i in range((size[0] * size[1])):
        image = np.array(img[:, i], dtype="float")
        image = image.reshape((30, 30))
        arr = np.array(image, dtype=float)
        ax = mtplot.subplot(size[0], size[1], i + 1)
        ax.axis('off')
        mtplot.title("Eig " + str(i))
        mtplot.imshow(arr, cmap='gray')
    mtplot.show()


def convertFace(X, eigenfaces):
    return np.dot(X.transpose(), eigenfaces)


def createDataset(address, eighen):
    data = []
    if len(glob.glob(address + "\\*")) > 0:
        if len(glob.glob((address + "\\*.pgm"))) > 0:
            for f in glob.glob((address + "\\*.pgm")):
                flat, _ = loadImage(f)
                flat = np.array(flat)
                if len(data) > 0:
                    data.append((f.split("\\")[len(f.split("\\")) - 2], convertFace(flat, eighen)))
                else:
                    data = [(f.split("\\")[len(f.split("\\")) - 2], convertFace(flat, eighen))]
        else:
            for f in glob.glob((address + "\\*")):
                if len(data) > 0:
                    data = data + createDataset(f, eighen)
                else:
                    data = createDataset(f, eighen)
    return data


def arrayAbs(input):
    sum = 0
    for i in range(len(input)):
        sum += int(abs(input[i]) ** 2)
    return np.sqrt(sum)


def kNN(dataset, input_face_vec, eigenfaces, k=5):
    input = convertFace(np.array(input_face_vec), eigenfaces)
    dataset = np.array(dataset)
    newDataSet = []
    for i in range(len(dataset)):
        if len(newDataSet) > 0:
            newDataSet = newDataSet + [(dataset[i][0], np.subtract(input, dataset[i][1][0]))]
        else:
            newDataSet = [(dataset[i][0], np.subtract(input, dataset[i][1][0]))]
    newDataSet = sorted(newDataSet, key=lambda x: arrayAbs(x[1][0]))
    print("Sorted : ")
    print(newDataSet)
    finalData = []
    for i in range(k, 0, -1):
        if len(finalData) > 0:
            finalData = finalData + [(newDataSet[len(newDataSet) - i][0], newDataSet[len(newDataSet) - i][1][0])]
        else:
            finalData = [(newDataSet[len(newDataSet) - i][0], newDataSet[len(newDataSet) - i][1][0])]
    names = []
    for i in range(len(finalData)):
        names.append(finalData[i][0])
    names = np.array(names)
    uniq, pos = np.unique(names, return_inverse=True)
    binCount = np.bincount(pos)
    return finalData, uniq[binCount.argmax()]

